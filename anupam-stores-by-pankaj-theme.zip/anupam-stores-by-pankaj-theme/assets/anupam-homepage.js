(function () {
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function initSlider(wrapper, options = {}) {
    const track = options.track || $('[data-slider-track]', wrapper) || $('.slider-track', wrapper);
    if (!track) return null;

    const prev = options.prev || $('[data-slider-prev]', wrapper) || $('.slider-btn.prev', wrapper);
    const next = options.next || $('[data-slider-next]', wrapper) || $('.slider-btn.next', wrapper);
    const loop = Boolean(options.loop);

    const amount = () => {
      const item = track.querySelector('[data-slider-item], .product-card, .category-item, .brand-card, .hero-slide, .promo-slide, .deal-card');
      if (!item) return track.clientWidth * 0.8;
      const style = getComputedStyle(track);
      const gap = parseFloat(style.columnGap || style.gap) || 16;
      return item.getBoundingClientRect().width + gap;
    };

    const maxScroll = () => Math.max(0, track.scrollWidth - track.clientWidth - 2);

    const sync = () => {
      const max = maxScroll();
      const atStart = track.scrollLeft <= 2;
      const atEnd = track.scrollLeft >= max;
      if (prev) prev.disabled = !loop && atStart;
      if (next) next.disabled = !loop && atEnd;
    };

    const go = (dir) => {
      const max = maxScroll();
      if (loop) {
        if (dir > 0 && track.scrollLeft >= max) {
          track.scrollTo({ left: 0, behavior: 'smooth' });
          return;
        }
        if (dir < 0 && track.scrollLeft <= 2) {
          track.scrollTo({ left: max, behavior: 'smooth' });
          return;
        }
      }
      track.scrollBy({ left: dir * amount(), behavior: 'smooth' });
    };

    prev && prev.addEventListener('click', () => go(-1));
    next && next.addEventListener('click', () => go(1));
    track.addEventListener('scroll', sync, { passive: true });
    window.addEventListener('resize', sync);
    sync();
    return { track, go, sync };
  }

  $$('[data-slider]').forEach((wrapper) => {
    initSlider(wrapper, {
      loop: wrapper.classList.contains('hero-slider')
        || wrapper.classList.contains('promo-banner')
        || wrapper.querySelector('.hero-track')
    });
  });

  const dealsWrap = $('.deals-slider');
  if (dealsWrap) {
    const deals = initSlider(dealsWrap);
    $('[data-deals-prev]')?.addEventListener('click', () => deals && deals.go(-1));
    $('[data-deals-next]')?.addEventListener('click', () => deals && deals.go(1));
  }

  const featuredWrap = $('.featured-slider');
  if (featuredWrap) {
    const featured = initSlider(featuredWrap);
    $('[data-featured-prev]')?.addEventListener('click', () => featured && featured.go(-1));
    $('[data-featured-next]')?.addEventListener('click', () => featured && featured.go(1));
  }

  const hero = $('.hero-slider');
  if (hero) {
    const heroSlider = initSlider(hero, { loop: true });
    const autoplay = hero.getAttribute('data-autoplay');
    if (heroSlider && autoplay && autoplay !== 'false') {
      const speed = parseInt(hero.getAttribute('data-autoplay-speed'), 10) || 5000;
      setInterval(() => heroSlider.go(1), speed);
    }
  }

  const searchToggle = $('.search-toggle');
  const headerSearch = $('.header-search, form.anupam-search-bar');
  searchToggle?.addEventListener('click', () => {
    headerSearch?.classList.toggle('is-open');
    const expanded = headerSearch?.classList.contains('is-open');
    searchToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    if (expanded) headerSearch.querySelector('input')?.focus();
  });

  const promoSec = document.querySelector('.promo-banner')?.closest('.shopify-section');
  const featuredEl = document.querySelector('.section.featured');
  if (promoSec && featuredEl && featuredEl.parentNode) {
    featuredEl.parentNode.insertBefore(promoSec, featuredEl);
  }
})();
