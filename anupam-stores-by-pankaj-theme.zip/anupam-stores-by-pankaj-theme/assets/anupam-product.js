(function () {
  const page = document.body.classList.contains('template-product');
  if (!page) return;

  function initGallery() {
    const root = document.querySelector('[data-gallery]');
    const main = document.querySelector('[data-gallery-main] img');
    const thumbs = Array.from(document.querySelectorAll('.pdp-thumb'));
    const dots = Array.from(document.querySelectorAll('.pdp-dot'));
    const track = document.querySelector('[data-thumbs]');
    if (!root || !main || !thumbs.length) return;

    const sources = thumbs.map((thumb) => thumb.getAttribute('data-full') || thumb.querySelector('img')?.getAttribute('src') || '');
    let index = Math.max(0, thumbs.findIndex((thumb) => thumb.classList.contains('is-active')));

    function setIndex(next) {
      const total = sources.length;
      const target = ((next % total) + total) % total;
      index = target;
      if (sources[index]) {
        main.classList.add('is-fading');
        window.setTimeout(() => {
          main.src = sources[index];
          if (main.hasAttribute('data-mfp-src')) main.setAttribute('data-mfp-src', sources[index]);
          main.setAttribute('data-image-id', thumbs[index].getAttribute('data-image-id') || '');
          main.classList.remove('is-fading');
        }, 120);
      }
      thumbs.forEach((thumb, i) => {
        thumb.classList.toggle('is-active', i === index);
        if (i === index) thumb.setAttribute('aria-current', 'true');
        else thumb.removeAttribute('aria-current');
      });
      dots.forEach((dot, i) => dot.classList.toggle('is-active', i === index));
      const active = thumbs[index];
      if (active && track) {
        const horizontal = window.matchMedia('(max-width: 767px)').matches;
        if (horizontal) track.scrollTo({ left: active.offsetLeft - 8, behavior: 'smooth' });
        else track.scrollTo({ top: active.offsetTop - 8, behavior: 'smooth' });
      }
    }

    thumbs.forEach((thumb) => {
      thumb.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        setIndex(Number(thumb.getAttribute('data-index')));
      });
    });
    dots.forEach((dot) => {
      dot.addEventListener('click', () => setIndex(Number(dot.getAttribute('data-index'))));
    });
    document.querySelector('[data-gallery-prev]')?.addEventListener('click', (event) => {
      event.preventDefault();
      setIndex(index - 1);
    });
    document.querySelector('[data-gallery-next]')?.addEventListener('click', (event) => {
      event.preventDefault();
      setIndex(index + 1);
    });

    const scrollThumbs = (dir) => {
      if (!track) return;
      const amount = 74;
      if (window.matchMedia('(max-width: 767px)').matches) track.scrollBy({ left: dir * amount, behavior: 'smooth' });
      else track.scrollBy({ top: dir * amount, behavior: 'smooth' });
    };
    document.querySelector('[data-thumbs-prev]')?.addEventListener('click', (event) => {
      event.preventDefault();
      scrollThumbs(-1);
    });
    document.querySelector('[data-thumbs-next]')?.addEventListener('click', (event) => {
      event.preventDefault();
      scrollThumbs(1);
    });

    let startX = 0;
    const stage = document.querySelector('.pdp-stage');
    stage?.addEventListener('touchstart', (e) => {
      startX = e.changedTouches[0].clientX;
    }, { passive: true });
    stage?.addEventListener('touchend', (e) => {
      const dx = e.changedTouches[0].clientX - startX;
      if (Math.abs(dx) < 40) return;
      setIndex(dx < 0 ? index + 1 : index - 1);
    }, { passive: true });
  }

  function initAccordions() {
    document.querySelectorAll('.pdp-acc').forEach((acc) => {
      acc.addEventListener('click', (event) => {
        const toggle = event.target.closest('.pdp-acc-toggle');
        if (!toggle || !acc.contains(toggle)) return;
        event.preventDefault();
        event.stopPropagation();
        const item = toggle.closest('.pdp-acc-item');
        if (!item) return;
        const open = item.classList.contains('is-open');
        acc.querySelectorAll('.pdp-acc-item').forEach((row) => {
          row.classList.remove('is-open');
          row.querySelector('.pdp-acc-toggle')?.setAttribute('aria-expanded', 'false');
          const icon = row.querySelector('.pdp-acc-toggle .material-symbols-outlined');
          if (icon) icon.textContent = 'add';
        });
        if (!open) {
          item.classList.add('is-open');
          toggle.setAttribute('aria-expanded', 'true');
          const icon = toggle.querySelector('.material-symbols-outlined');
          if (icon) icon.textContent = 'remove';
        }
      });
    });
  }

  function initQuantity() {
    const input = document.querySelector('#product-qty .quantity__input, .pdp-qty .quantity__input');
    if (!input) return;
    const clamp = (value) => {
      const n = parseInt(value, 10);
      if (Number.isNaN(n) || n < 1) return 1;
      return Math.min(99, n);
    };
    document.querySelector('#product-qty [name="minus"], .pdp-qty [name="minus"]')?.addEventListener('click', () => {
      input.value = String(clamp(Number(input.value) - 1));
    });
    document.querySelector('#product-qty [name="plus"], .pdp-qty [name="plus"]')?.addEventListener('click', () => {
      input.value = String(clamp(Number(input.value) + 1));
    });
  }

  function initBuyLabel() {
    document.querySelectorAll('.shopify-payment-button__button, .shopify-payment-button button').forEach((btn) => {
      const label = (btn.textContent || '').replace(/\s+/g, ' ').trim();
      if (/buy it now/i.test(label)) {
        Array.from(btn.childNodes).forEach((node) => {
          if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) node.textContent = ' Buy Now ';
        });
        if (!btn.childNodes.length || !/buy now/i.test(btn.textContent || '')) {
          btn.textContent = 'Buy Now';
        }
      }
    });
  }

  function initJudgeMeReviewLink() {
    if (document.documentElement.dataset.judgeMeReviewLinkBound === 'true') return;
    document.documentElement.dataset.judgeMeReviewLinkBound = 'true';

    const getWidget = () => (
      document.querySelector('#judgeme_product_reviews') ||
      document.querySelector('.jdgm-review-widget')
    );

    const findWriteControl = (widget) => {
      if (!widget) return null;

      const controls = Array.from(
        widget.querySelectorAll('button, a, input[type="button"], input[type="submit"]')
      );

      return controls.find((control) => {
        const text = (control.textContent || control.value || '')
          .replace(/\s+/g, ' ')
          .trim()
          .toLowerCase();

        return (
          text.includes('write a review') ||
          text === 'write review' ||
          text.includes('review this product')
        );
      }) || null;
    };

    const openJudgeMeForm = (attempts = 0) => {
      const widget = getWidget();
      if (!widget) {
        if (attempts < 40) {
          window.setTimeout(() => openJudgeMeForm(attempts + 1), 250);
        }
        return;
      }

      widget.scrollIntoView({ behavior: 'smooth', block: 'start' });

      const control = findWriteControl(widget);
      if (control) {
        control.click();
        return;
      }

      // Judge.me loads its internal UI asynchronously. Keep checking briefly
      // instead of failing when the customer clicks before the widget finishes.
      if (attempts < 40) {
        window.setTimeout(() => openJudgeMeForm(attempts + 1), 250);
      }
    };

    document.addEventListener('click', (event) => {
      const link = event.target.closest('[data-review-open]');
      if (!link) return;

      event.preventDefault();
      openJudgeMeForm();
    });
  }

  initGallery();
  initAccordions();
  initQuantity();
  initBuyLabel();
  initJudgeMeReviewLink();
  const buyRoot = document.querySelector('.pdp-cta, .product-form__buttons');
  if (buyRoot && window.MutationObserver) {
    const observer = new MutationObserver(initBuyLabel);
    observer.observe(buyRoot, { childList: true, subtree: true, characterData: true });
  }
})();
